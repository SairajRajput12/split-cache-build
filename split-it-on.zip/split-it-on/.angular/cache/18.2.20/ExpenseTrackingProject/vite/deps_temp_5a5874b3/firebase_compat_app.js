import "./chunk-V2W2CMHM.js";
import {
  firebase
} from "./chunk-NEKU525M.js";
import "./chunk-35ENWJA4.js";
export {
  firebase as default
};
//# sourceMappingURL=firebase_compat_app.js.map
