const express = require("express");
const fs = require("fs");
const https = require("https");
const history = require("connect-history-api-fallback");
const jsonServer = require("json-server");
const bodyParser = require("body-parser");
const auth = require("./authMiddleware.js");
const router = jsonServer.router("serverdata.json");

const app = express();

app.use(bodyParser.json());
app.use(auth);

app.use("/api", router);

app.use(history());

app.use(express.static("./dist/expense-tracking-project/browser"));

app.listen(3500, () => console.log("HTTP Server running on port 3500"));
