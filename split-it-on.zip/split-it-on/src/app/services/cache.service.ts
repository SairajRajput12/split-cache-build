import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root',
  // this service must be injected once and must be used into the root module once.
})
export class CacheService {
  private cache = new Map<string, any[]>();
//   public cache$ = new BehaviorSubject<any[]>(null);
}
