import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'expense',
  templateUrl: 'addExpense.component.html',
})
export class AddExpenseComponent {
  constructor() {}
}
